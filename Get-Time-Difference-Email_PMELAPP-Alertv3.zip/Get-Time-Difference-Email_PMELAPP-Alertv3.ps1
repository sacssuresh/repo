<#
Author: Hariharan Neelagiri Nagarajan
v1 - Script Created
v2 - Alert Threshold Changed to 30 Milli Seconds
v3 - Clear Alert Added
#>

$AServers = "C:\InfraOps\Time-Difference\AAffectedServers.txt"
$Th01 = "0"
$Th02 = "500"
$Th03 = "-500"

If ((Get-Content $AServers) -eq $Null) {

    Write-Host "***** All Previous Alerts are Cleared. No need to run Clear Alert Script *****" -ForegroundColor Cyan
    Write-Host "***************************** Closing the Clear Alert Script *****************************" -ForegroundColor Cyan
  }  
   Else {

   Write-Host "***** Running Clear Alert Script to check Previous Alerts are still On-Board *****" -ForegroundColor Cyan
   $ClearAlertScript= "C:\InfraOps\Time-Difference\Get-Time-Difference-PMELAPP-ClearAlertv3.ps1"
   &$ClearAlertScript
}

Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "************** Starting to Check Time Different on APP Tier *************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor White

Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "************* Checking Time Difference on PROD ANLY Servers *************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor White


$servers = gc "C:\InfraOps\Time-Difference\APP-ANLY.txt"

foreach ($server in $servers){

$Time = (icm $Server {get-date})
$Timezone = (icm $Server {Get-WmiObject win32_timezone})
#Write-Host "Current time on $Server in EST is $Time & Timezone configured is $($Timezone.Caption)" -ForegroundColor Cyan
$Diff = New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds
$Msg1 = "Time is Out of Sync on Server $($Server). Difference is"
$Msg2 = "$($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms"
$Msg3 = "This alert has triggered since the threshold (Above 500 Milli Seconds) for time difference has breached. Please restart PresenTense Client Service on Server $Server. Please wait for 3-5 minutes and check the time difference again using the below PowerShell command."
$Msg4 = "New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds"
$Msg5 = "Note: Timezone configured on the server is $($Timezone.Caption)."
$AlertHTMLBody = "
<html><body>
<font color='000000'>$Msg1</font>
<font color='8B0000'><b>$Msg2</b></font><br /><br />
<font color='808080'>$msg3</font><br /><br />
<font color='808080'>$msg4</font><br /><br />
<font color='808080'>$msg5</font>
<body><html>
"
If (($($Diff.Seconds) -gt $Th01) -or ($($Diff.Seconds) -lt $Th01) -or ($($Diff.MilliSeconds) -gt $Th02) -or ($($Diff.MilliSeconds) -lt $Th03) -or ($($Diff.Minutes) -gt $Th01) -or ($($Diff.Minutes) -lt $Th01)) {

  Send-MailMessage -From 'TCC Server Time Check - Alert <TCCServerTimeCheck.Alert@resideo.com>' -To 'TCC Tier 2 Support <DL-TCCTier2Support@resideo.com>' -Cc 'Hariharan <hariharan.neelagirinagarajan@resideo.com>' -Subject "CRITICAL - $Server - Time Out of Sync" -BodyAsHtml $AlertHTMLBody -Priority High -SmtpServer '10.6.210.61'  
  Add-Content -Value $Server -Path $AServers
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is Out Of Sync." -ForegroundColor RED

  }  
Else {
 
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is in Sync." -ForegroundColor GREEN
 
  }
}

Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "************* Checking Time Difference on PROD AUTH Servers *************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor White

$servers = gc "C:\InfraOps\Time-Difference\APP-AUTH.txt"

foreach ($server in $servers){

$Time = (icm $Server {get-date})
$Timezone = (icm $Server {Get-WmiObject win32_timezone})
#Write-Host "Current time on $Server in EST is $Time & Timezone configured is $($Timezone.Caption)" -ForegroundColor Cyan
$Diff = New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds
$Msg1 = "Time is Out of Sync on Server $($Server). Difference is"
$Msg2 = "$($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms"
$Msg3 = "This alert has triggered since the threshold (Above 500 Milli Seconds) for time difference has breached. Please restart PresenTense Client Service on Server $Server. Please wait for 3-5 minutes and check the time difference again using the below PowerShell command."
$Msg4 = "New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds"
$Msg5 = "Note: Timezone configured on the server is $($Timezone.Caption)."
$AlertHTMLBody = "
<html><body>
<font color='000000'>$Msg1</font>
<font color='8B0000'><b>$Msg2</b></font><br /><br />
<font color='808080'>$msg3</font><br /><br />
<font color='808080'>$msg4</font><br /><br />
<font color='808080'>$msg5</font>
<body><html>
"
If (($($Diff.Seconds) -gt $Th01) -or ($($Diff.Seconds) -lt $Th01) -or ($($Diff.MilliSeconds) -gt $Th02) -or ($($Diff.MilliSeconds) -lt $Th03) -or ($($Diff.Minutes) -gt $Th01) -or ($($Diff.Minutes) -lt $Th01)) {

  Send-MailMessage -From 'TCC Server Time Check - Alert <TCCServerTimeCheck.Alert@resideo.com>' -To 'TCC Tier 2 Support <DL-TCCTier2Support@resideo.com>' -Cc 'Hariharan <hariharan.neelagirinagarajan@resideo.com>' -Subject "CRITICAL - $Server - Time Out of Sync" -BodyAsHtml $AlertHTMLBody -Priority High -SmtpServer '10.6.210.61'  
  Add-Content -Value $Server -Path $AServers
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is Out Of Sync." -ForegroundColor RED

  }  
Else {
 
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is in Sync." -ForegroundColor GREEN
 
  }
}


Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "********** Checking Time Difference on PROD Couch Base Servers **********" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor White

$servers = gc "C:\InfraOps\Time-Difference\APP-CB.txt"

foreach ($server in $servers){

$Time = (icm $Server {get-date})
$Timezone = (icm $Server {Get-WmiObject win32_timezone})
#Write-Host "Current time on $Server in EST is $Time & Timezone configured is $($Timezone.Caption)" -ForegroundColor Cyan
$Diff = New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds
$Msg1 = "Time is Out of Sync on Server $($Server). Difference is"
$Msg2 = "$($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms"
$Msg3 = "This alert has triggered since the threshold (Above 500 Milli Seconds) for time difference has breached. Please restart PresenTense Client Service on Server $Server. Please wait for 3-5 minutes and check the time difference again using the below PowerShell command."
$Msg4 = "New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds"
$Msg5 = "Note: Timezone configured on the server is $($Timezone.Caption)."
$AlertHTMLBody = "
<html><body>
<font color='000000'>$Msg1</font>
<font color='8B0000'><b>$Msg2</b></font><br /><br />
<font color='808080'>$msg3</font><br /><br />
<font color='808080'>$msg4</font><br /><br />
<font color='808080'>$msg5</font>
<body><html>
"
If (($($Diff.Seconds) -gt $Th01) -or ($($Diff.Seconds) -lt $Th01) -or ($($Diff.MilliSeconds) -gt $Th02) -or ($($Diff.MilliSeconds) -lt $Th03) -or ($($Diff.Minutes) -gt $Th01) -or ($($Diff.Minutes) -lt $Th01)) {

  Send-MailMessage -From 'TCC Server Time Check - Alert <TCCServerTimeCheck.Alert@resideo.com>' -To 'TCC Tier 2 Support <DL-TCCTier2Support@resideo.com>' -Cc 'Hariharan <hariharan.neelagirinagarajan@resideo.com>' -Subject "CRITICAL - $Server - Time Out of Sync" -BodyAsHtml $AlertHTMLBody -Priority High -SmtpServer '10.6.210.61'  
  Add-Content -Value $Server -Path $AServers
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is Out Of Sync." -ForegroundColor RED

  }  
Else {
 
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is in Sync." -ForegroundColor GREEN
 
  }
}


Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "************* Checking Time Difference on PROD COMM Servers *************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor White

$servers = gc "C:\InfraOps\Time-Difference\APP-COMM.txt"

foreach ($server in $servers){

$Time = (icm $Server {get-date})
$Timezone = (icm $Server {Get-WmiObject win32_timezone})
#Write-Host "Current time on $Server in EST is $Time & Timezone configured is $($Timezone.Caption)" -ForegroundColor Cyan
$Diff = New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds
$Msg1 = "Time is Out of Sync on Server $($Server). Difference is"
$Msg2 = "$($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms"
$Msg3 = "This alert has triggered since the threshold (Above 500 Milli Seconds) for time difference has breached. Please restart PresenTense Client Service on Server $Server. Please wait for 3-5 minutes and check the time difference again using the below PowerShell command."
$Msg4 = "New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds"
$Msg5 = "Note: Timezone configured on the server is $($Timezone.Caption)."
$AlertHTMLBody = "
<html><body>
<font color='000000'>$Msg1</font>
<font color='8B0000'><b>$Msg2</b></font><br /><br />
<font color='808080'>$msg3</font><br /><br />
<font color='808080'>$msg4</font><br /><br />
<font color='808080'>$msg5</font>
<body><html>
"
If (($($Diff.Seconds) -gt $Th01) -or ($($Diff.Seconds) -lt $Th01) -or ($($Diff.MilliSeconds) -gt $Th02) -or ($($Diff.MilliSeconds) -lt $Th03) -or ($($Diff.Minutes) -gt $Th01) -or ($($Diff.Minutes) -lt $Th01)) {

  Send-MailMessage -From 'TCC Server Time Check - Alert <TCCServerTimeCheck.Alert@resideo.com>' -To 'TCC Tier 2 Support <DL-TCCTier2Support@resideo.com>' -Cc 'Hariharan <hariharan.neelagirinagarajan@resideo.com>' -Subject "CRITICAL - $Server - Time Out of Sync" -BodyAsHtml $AlertHTMLBody -Priority High -SmtpServer '10.6.210.61'  
  Add-Content -Value $Server -Path $AServers
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is Out Of Sync." -ForegroundColor RED

  }  
Else {
 
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is in Sync." -ForegroundColor GREEN
 
  }
}


Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*********** Checking Time Difference on PROD Front End Servers **********" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor White

$servers = gc "C:\InfraOps\Time-Difference\APP-FE.txt"

foreach ($server in $servers){

$Time = (icm $Server {get-date})
$Timezone = (icm $Server {Get-WmiObject win32_timezone})
#Write-Host "Current time on $Server in EST is $Time & Timezone configured is $($Timezone.Caption)" -ForegroundColor Cyan
$Diff = New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds
$Msg1 = "Time is Out of Sync on Server $($Server). Difference is"
$Msg2 = "$($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms"
$Msg3 = "This alert has triggered since the threshold (Above 500 Milli Seconds) for time difference has breached. Please restart PresenTense Client Service on Server $Server. Please wait for 3-5 minutes and check the time difference again using the below PowerShell command."
$Msg4 = "New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds"
$Msg5 = "Note: Timezone configured on the server is $($Timezone.Caption)."
$AlertHTMLBody = "
<html><body>
<font color='000000'>$Msg1</font>
<font color='8B0000'><b>$Msg2</b></font><br /><br />
<font color='808080'>$msg3</font><br /><br />
<font color='808080'>$msg4</font><br /><br />
<font color='808080'>$msg5</font>
<body><html>
"
If (($($Diff.Seconds) -gt $Th01) -or ($($Diff.Seconds) -lt $Th01) -or ($($Diff.MilliSeconds) -gt $Th02) -or ($($Diff.MilliSeconds) -lt $Th03) -or ($($Diff.Minutes) -gt $Th01) -or ($($Diff.Minutes) -lt $Th01)) {

  Send-MailMessage -From 'TCC Server Time Check - Alert <TCCServerTimeCheck.Alert@resideo.com>' -To 'TCC Tier 2 Support <DL-TCCTier2Support@resideo.com>' -Cc 'Hariharan <hariharan.neelagirinagarajan@resideo.com>' -Subject "CRITICAL - $Server - Time Out of Sync" -BodyAsHtml $AlertHTMLBody -Priority High -SmtpServer '10.6.210.61'  
  Add-Content -Value $Server -Path $AServers
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is Out Of Sync." -ForegroundColor RED

  }  
Else {
 
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is in Sync." -ForegroundColor GREEN
 
  }
}


Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "************** Checking Time Difference on PROD RAS Servers *************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor White

$servers = gc "C:\InfraOps\Time-Difference\APP-RAS.txt"

foreach ($server in $servers){

$Time = (icm $Server {get-date})
$Timezone = (icm $Server {Get-WmiObject win32_timezone})
#Write-Host "Current time on $Server in EST is $Time & Timezone configured is $($Timezone.Caption)" -ForegroundColor Cyan
$Diff = New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds
$Msg1 = "Time is Out of Sync on Server $($Server). Difference is"
$Msg2 = "$($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms"
$Msg3 = "This alert has triggered since the threshold (Above 500 Milli Seconds) for time difference has breached. Please restart PresenTense Client Service on Server $Server. Please wait for 3-5 minutes and check the time difference again using the below PowerShell command."
$Msg4 = "New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds"
$Msg5 = "Note: Timezone configured on the server is $($Timezone.Caption)."
$AlertHTMLBody = "
<html><body>
<font color='000000'>$Msg1</font>
<font color='8B0000'><b>$Msg2</b></font><br /><br />
<font color='808080'>$msg3</font><br /><br />
<font color='808080'>$msg4</font><br /><br />
<font color='808080'>$msg5</font>
<body><html>
"
If (($($Diff.Seconds) -gt $Th01) -or ($($Diff.Seconds) -lt $Th01) -or ($($Diff.MilliSeconds) -gt $Th02) -or ($($Diff.MilliSeconds) -lt $Th03) -or ($($Diff.Minutes) -gt $Th01) -or ($($Diff.Minutes) -lt $Th01)) {

  Send-MailMessage -From 'TCC Server Time Check - Alert <TCCServerTimeCheck.Alert@resideo.com>' -To 'TCC Tier 2 Support <DL-TCCTier2Support@resideo.com>' -Cc 'Hariharan <hariharan.neelagirinagarajan@resideo.com>' -Subject "CRITICAL - $Server - Time Out of Sync" -BodyAsHtml $AlertHTMLBody -Priority High -SmtpServer '10.6.210.61'  
  Add-Content -Value $Server -Path $AServers
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is Out Of Sync." -ForegroundColor RED

  }  
Else {
 
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is in Sync." -ForegroundColor GREEN
 
  }
}


Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "************** Checking Time Difference on PROD RMQ Servers *************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor White

$servers = gc "C:\InfraOps\Time-Difference\APP-RMQ.txt"

foreach ($server in $servers){

$Time = (icm $Server {get-date})
$Timezone = (icm $Server {Get-WmiObject win32_timezone})
#Write-Host "Current time on $Server in EST is $Time & Timezone configured is $($Timezone.Caption)" -ForegroundColor Cyan
$Diff = New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds
$Msg1 = "Time is Out of Sync on Server $($Server). Difference is"
$Msg2 = "$($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms"
$Msg3 = "This alert has triggered since the threshold (Above 500 Milli Seconds) for time difference has breached. Please restart PresenTense Client Service on Server $Server. Please wait for 3-5 minutes and check the time difference again using the below PowerShell command."
$Msg4 = "New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds"
$Msg5 = "Note: Timezone configured on the server is $($Timezone.Caption)."
$AlertHTMLBody = "
<html><body>
<font color='000000'>$Msg1</font>
<font color='8B0000'><b>$Msg2</b></font><br /><br />
<font color='808080'>$msg3</font><br /><br />
<font color='808080'>$msg4</font><br /><br />
<font color='808080'>$msg5</font>
<body><html>
"
If (($($Diff.Seconds) -gt $Th01) -or ($($Diff.Seconds) -lt $Th01) -or ($($Diff.MilliSeconds) -gt $Th02) -or ($($Diff.MilliSeconds) -lt $Th03) -or ($($Diff.Minutes) -gt $Th01) -or ($($Diff.Minutes) -lt $Th01)) {

  Send-MailMessage -From 'TCC Server Time Check - Alert <TCCServerTimeCheck.Alert@resideo.com>' -To 'TCC Tier 2 Support <DL-TCCTier2Support@resideo.com>' -Cc 'Hariharan <hariharan.neelagirinagarajan@resideo.com>' -Subject "CRITICAL - $Server - Time Out of Sync" -BodyAsHtml $AlertHTMLBody -Priority High -SmtpServer '10.6.210.61'  
  Add-Content -Value $Server -Path $AServers
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is Out Of Sync." -ForegroundColor RED

  }  
Else {
 
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is in Sync." -ForegroundColor GREEN
 
  }
}


Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*********** Checking Time Difference on PROD True Home Servers **********" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor White


$servers = gc "C:\InfraOps\Time-Difference\APP-TH.txt"

foreach ($server in $servers){

$Time = (icm $Server {get-date})
$Timezone = (icm $Server {Get-WmiObject win32_timezone})
#Write-Host "Current time on $Server in EST is $Time & Timezone configured is $($Timezone.Caption)" -ForegroundColor Cyan
$Diff = New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds
$Msg1 = "Time is Out of Sync on Server $($Server). Difference is"
$Msg2 = "$($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms"
$Msg3 = "This alert has triggered since the threshold (Above 500 Milli Seconds) for time difference has breached. Please restart PresenTense Client Service on Server $Server. Please wait for 3-5 minutes and check the time difference again using the below PowerShell command."
$Msg4 = "New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds"
$Msg5 = "Note: Timezone configured on the server is $($Timezone.Caption)."
$AlertHTMLBody = "
<html><body>
<font color='000000'>$Msg1</font>
<font color='8B0000'><b>$Msg2</b></font><br /><br />
<font color='808080'>$msg3</font><br /><br />
<font color='808080'>$msg4</font><br /><br />
<font color='808080'>$msg5</font>
<body><html>
"
If (($($Diff.Seconds) -gt $Th01) -or ($($Diff.Seconds) -lt $Th01) -or ($($Diff.MilliSeconds) -gt $Th02) -or ($($Diff.MilliSeconds) -lt $Th03) -or ($($Diff.Minutes) -gt $Th01) -or ($($Diff.Minutes) -lt $Th01)) {

  Send-MailMessage -From 'TCC Server Time Check - Alert <TCCServerTimeCheck.Alert@resideo.com>' -To 'TCC Tier 2 Support <DL-TCCTier2Support@resideo.com>' -Cc 'Hariharan <hariharan.neelagirinagarajan@resideo.com>' -Subject "CRITICAL - $Server - Time Out of Sync" -BodyAsHtml $AlertHTMLBody -Priority High -SmtpServer '10.6.210.61'  
  Add-Content -Value $Server -Path $AServers
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is Out Of Sync." -ForegroundColor RED

  }  
Else {
 
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is in Sync." -ForegroundColor GREEN
 
  }
}


Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "************** Checking Time Difference on PROD DB Servers **************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor White

$servers = gc "C:\InfraOps\Time-Difference\APP-SQL.txt"

foreach ($server in $servers){

$Time = (icm $Server {get-date})
$Timezone = (icm $Server {Get-WmiObject win32_timezone})
#Write-Host "Current time on $Server in EST is $Time & Timezone configured is $($Timezone.Caption)" -ForegroundColor Cyan
$Diff = New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds
$Msg1 = "Time is Out of Sync on Server $($Server). Difference is"
$Msg2 = "$($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms"
$Msg3 = "This alert has triggered since the threshold (Above 500 Milli Seconds) for time difference has breached. Please restart PresenTense Client Service on Server $Server. Please wait for 3-5 minutes and check the time difference again using the below PowerShell command."
$Msg4 = "New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds"
$Msg5 = "Note: Timezone configured on the server is $($Timezone.Caption)."
$AlertHTMLBody = "
<html><body>
<font color='000000'>$Msg1</font>
<font color='8B0000'><b>$Msg2</b></font><br /><br />
<font color='808080'>$msg3</font><br /><br />
<font color='808080'>$msg4</font><br /><br />
<font color='808080'>$msg5</font>
<body><html>
"
If (($($Diff.Seconds) -gt $Th01) -or ($($Diff.Seconds) -lt $Th01) -or ($($Diff.MilliSeconds) -gt $Th02) -or ($($Diff.MilliSeconds) -lt $Th03) -or ($($Diff.Minutes) -gt $Th01) -or ($($Diff.Minutes) -lt $Th01)) {

  Send-MailMessage -From 'TCC Server Time Check - Alert <TCCServerTimeCheck.Alert@resideo.com>' -To 'TCC Tier 2 Support <DL-TCCTier2Support@resideo.com>' -Cc 'Hariharan <hariharan.neelagirinagarajan@resideo.com>' -Subject "CRITICAL - $Server - Time Out of Sync" -BodyAsHtml $AlertHTMLBody -Priority High -SmtpServer '10.6.210.61'  
  Add-Content -Value $Server -Path $AServers
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is Out Of Sync." -ForegroundColor RED

  }  
Else {
 
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is in Sync." -ForegroundColor GREEN
 
  }
}


Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*********** Checking Time Difference on App Tier MGMT Servers ***********" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor White

$servers = gc "C:\InfraOps\Time-Difference\APP-MGMT.txt"

foreach ($server in $servers){

$Time = (icm $Server {get-date})
$Timezone = (icm $Server {Get-WmiObject win32_timezone})
#Write-Host "Current time on $Server in EST is $Time & Timezone configured is $($Timezone.Caption)" -ForegroundColor Cyan
$Diff = New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds
$Msg1 = "Time is Out of Sync on Server $($Server). Difference is"
$Msg2 = "$($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms"
$Msg3 = "This alert has triggered since the threshold (Above 500 Milli Seconds) for time difference has breached. Please restart PresenTense Client Service on Server $Server. Please wait for 3-5 minutes and check the time difference again using the below PowerShell command."
$Msg4 = "New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds"
$Msg5 = "Note: Timezone configured on the server is $($Timezone.Caption)."
$AlertHTMLBody = "
<html><body>
<font color='000000'>$Msg1</font>
<font color='8B0000'><b>$Msg2</b></font><br /><br />
<font color='808080'>$msg3</font><br /><br />
<font color='808080'>$msg4</font><br /><br />
<font color='808080'>$msg5</font>
<body><html>
"
If (($($Diff.Seconds) -gt $Th01) -or ($($Diff.Seconds) -lt $Th01) -or ($($Diff.MilliSeconds) -gt $Th02) -or ($($Diff.MilliSeconds) -lt $Th03) -or ($($Diff.Minutes) -gt $Th01) -or ($($Diff.Minutes) -lt $Th01)) {

  Send-MailMessage -From 'TCC Server Time Check - Alert <TCCServerTimeCheck.Alert@resideo.com>' -To 'TCC Tier 2 Support <DL-TCCTier2Support@resideo.com>' -Cc 'Hariharan <hariharan.neelagirinagarajan@resideo.com>' -Subject "CRITICAL - $Server - Time Out of Sync" -BodyAsHtml $AlertHTMLBody -Priority High -SmtpServer '10.6.210.61'  
  Add-Content -Value $Server -Path $AServers
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is Out Of Sync." -ForegroundColor RED

  }  
Else {
 
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is in Sync." -ForegroundColor GREEN
 
  }
}


Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*********** Checking Time Difference on non-PROD APP Servers ************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor White

$servers = gc "C:\InfraOps\Time-Difference\QA-APP.txt"

foreach ($server in $servers){

$Time = (icm $Server {get-date})
$Timezone = (icm $Server {Get-WmiObject win32_timezone})
#Write-Host "Current time on $Server in EST is $Time & Timezone configured is $($Timezone.Caption)" -ForegroundColor Cyan
$Diff = New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds
$Msg1 = "Time is Out of Sync on Server $($Server). Difference is"
$Msg2 = "$($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms"
$Msg3 = "This alert has triggered since the threshold (Above 500 Milli Seconds) for time difference has breached. Please restart PresenTense Client Service on Server $Server. Please wait for 3-5 minutes and check the time difference again using the below PowerShell command."
$Msg4 = "New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds"
$Msg5 = "Note: Timezone configured on the server is $($Timezone.Caption)."
$AlertHTMLBody = "
<html><body>
<font color='000000'>$Msg1</font>
<font color='8B0000'><b>$Msg2</b></font><br /><br />
<font color='808080'>$msg3</font><br /><br />
<font color='808080'>$msg4</font><br /><br />
<font color='808080'>$msg5</font>
<body><html>
"
If (($($Diff.Seconds) -gt $Th01) -or ($($Diff.Seconds) -lt $Th01) -or ($($Diff.MilliSeconds) -gt $Th02) -or ($($Diff.MilliSeconds) -lt $Th03) -or ($($Diff.Minutes) -gt $Th01) -or ($($Diff.Minutes) -lt $Th01)) {

  Send-MailMessage -From 'TCC Server Time Check - Alert <TCCServerTimeCheck.Alert@resideo.com>' -To 'TCC Tier 2 Support <DL-TCCTier2Support@resideo.com>' -Cc 'Hariharan <hariharan.neelagirinagarajan@resideo.com>' -Subject "Warning - $Server - Time Out of Sync" -BodyAsHtml $AlertHTMLBody -Priority High -SmtpServer '10.6.210.61'  
  Add-Content -Value $Server -Path $AServers
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is Out Of Sync." -ForegroundColor RED

  }  
Else {
 
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is in Sync." -ForegroundColor GREEN
 
  }
}


Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "************ Checking Time Difference on non-PROD DB Servers ************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor Yellow
Write-Host "*************************************************************************" -ForegroundColor White

$servers = gc "C:\InfraOps\Time-Difference\QA-DB.txt"

foreach ($server in $servers){

$Time = (icm $Server {get-date})
$Timezone = (icm $Server {Get-WmiObject win32_timezone})
#Write-Host "Current time on $Server in EST is $Time & Timezone configured is $($Timezone.Caption)" -ForegroundColor Cyan
$Diff = New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds
$Msg1 = "Time is Out of Sync on Server $($Server). Difference is"
$Msg2 = "$($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms"
$Msg3 = "This alert has triggered since the threshold (Above 500 Milli Seconds) for time difference has breached. Please restart PresenTense Client Service on Server $Server. Please wait for 3-5 minutes and check the time difference again using the below PowerShell command."
$Msg4 = "New-TimeSpan -Start (icm $Server {get-date}) -End (get-date) | select Hours,Minutes,Seconds,MilliSeconds"
$Msg5 = "Note: Timezone configured on the server is $($Timezone.Caption)."
$AlertHTMLBody = "
<html><body>
<font color='000000'>$Msg1</font>
<font color='8B0000'><b>$Msg2</b></font><br /><br />
<font color='808080'>$msg3</font><br /><br />
<font color='808080'>$msg4</font><br /><br />
<font color='808080'>$msg5</font>
<body><html>
"
If (($($Diff.Seconds) -gt $Th01) -or ($($Diff.Seconds) -lt $Th01) -or ($($Diff.MilliSeconds) -gt $Th02) -or ($($Diff.MilliSeconds) -lt $Th03) -or ($($Diff.Minutes) -gt $Th01) -or ($($Diff.Minutes) -lt $Th01)) {

  Send-MailMessage -From 'TCC Server Time Check - Alert <TCCServerTimeCheck.Alert@resideo.com>' -To 'TCC Tier 2 Support <DL-TCCTier2Support@resideo.com>' -Cc 'Hariharan <hariharan.neelagirinagarajan@resideo.com>' -Subject "Warning - $Server - Time Out of Sync" -BodyAsHtml $AlertHTMLBody -Priority High -SmtpServer '10.6.210.61'  
  Add-Content -Value $Server -Path $AServers
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is Out Of Sync." -ForegroundColor RED

  }  
Else {
 
  Write-Host "Time Difference on $($Server) is $($Diff.Hours)H $($Diff.Minutes)M $($Diff.Seconds)S $($Diff.MilliSeconds)ms. Time is in Sync." -ForegroundColor GREEN
 
  }
}

  (Get-Content -Path $AServers) | ? {$_.trim() -ne "" } | Set-Content -Path $AServers
  (Get-Content -Path $AServers) | Sort-Object -Unique | Set-Content -Path $AServers 
  $AServersContent = (Get-Content -Path $AServers -Raw) -replace "(?s)`r`n\s*$"
  [system.io.file]::WriteAllText($AServers,$AServersContent)
#END